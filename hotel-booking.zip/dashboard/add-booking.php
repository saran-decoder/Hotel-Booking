<?php
    include "../libs/load.php";

    if (!Session::get('email_verified') == 'verified') {
        header("Location: 2fa");
        exit;
    }

    if (
        !Session::get('session_token') || 
        Session::get('session_type') != 'admin' && 
        !Session::get('username') || 
        Session::get('email_verified') != 'verified'
    ) {
        header("Location: logout?logout");
        exit;
    }

// Admin static functions for booking management
// class AdminBooking {
//     public static function getAllBookings() {
//         // Implementation to get all bookings
//     }
    
//     public static function getBookingById($id) {
//         // Implementation to get booking by ID
//     }
    
//     public static function updateBookingStatus($id, $status) {
//         // Implementation to update booking status
//     }
    
//     public static function cancelBooking($id) {
//         // Implementation to cancel booking
//     }
// }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Booking Management</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <?php include "temp/head.php" ?>

        <link rel="stylesheet" href="assets/css/booking.css">

    </head>
    <body>
        <div class="container-fluid">
            <div class="row">
                <!-- Sidebar -->
                <?php include "temp/sideheader.php" ?>

                <!-- Main Content -->
                <div class="main-content p-0 overflow-hidden">
                    <!-- Top Navbar -->
                    <?php include "temp/header.php" ?>

                    <div class="p-4">
                        <!-- Step Bar -->
                        <div class="container my-5">
                            <div class="progress-step">
                                <div class="step active" data-step="1">
                                    <span class="circle-number">1</span><br />
                                    Select Dates
                                </div>
                                <div class="step" data-step="2">
                                    <span class="circle-number">2</span><br />
                                    Choose Hotel
                                </div>
                                <div class="step" data-step="3">
                                    <span class="circle-number">3</span><br />
                                    Select Room
                                </div>
                                <div class="step" data-step="4">
                                    <span class="circle-number">4</span><br />
                                    Confirm Booking
                                </div>
                            </div>
                        </div>

                        <!-- Step 1: Select Dates -->
                        <div class="container mb-5 step-content active" id="step1">
                            <div class="card p-4 shadow-sm mx-auto" style="max-width: 700px;">
                                <h5 class="fw-bold mb-3">Select Your Stay Dates</h5>

                                <!-- Destination -->
                                <div class="bg-light p-3 rounded mb-4">
                                    <label class="form-label">Destination</label>
                                    <div class="input-group">
                                        <select class="form-select rounded" id="destinationSelect">
                                            <option value="" selected disabled>Select destination</option>
                                            <!-- Options will be populated by JavaScript -->
                                        </select>
                                    </div>
                                </div>

                                <!-- Calendar -->
                                <div class="card mb-4 p-3">
                                    <div class="d-flex justify-content-between align-items-center mb-3 calendar-header">
                                        <strong>Select Dates</strong>
                                        <div>
                                            <button class="btn" id="prevMonth"><i class="fas fa-chevron-left"></i></button>
                                            <span class="mx-2" id="currentMonth">July 2025</span>
                                            <button class="btn" id="nextMonth"><i class="fas fa-chevron-right"></i></button>
                                        </div>
                                    </div>
                                    <div class="row text-center text-muted mb-2 calendar-days">
                                        <div class="col p-1">Sun</div>
                                        <div class="col p-1">Mon</div>
                                        <div class="col p-1">Tue</div>
                                        <div class="col p-1">Wed</div>
                                        <div class="col p-1">Thu</div>
                                        <div class="col p-1">Fri</div>
                                        <div class="col p-1">Sat</div>
                                    </div>
                                    <div class="row text-center calendar-dates" id="calendarDates">
                                        <!-- Calendar dates will be generated by JavaScript -->
                                    </div>
                                </div>

                                <!-- Check-in and Check-out -->
                                <div class="row mb-3">
                                    <div class="col-md-6 mb-3 mb-md-0">
                                        <div class="form-box" id="checkInBox">
                                            <div class="small-label">Check-in</div>
                                            <div id="checkInDate">Select date</div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-box" id="checkOutBox">
                                            <div class="small-label">Check-out</div>
                                            <div id="checkOutDate">Select date</div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Guests -->
                                <div class="mb-4">
                                    <label class="form-label">Guests</label>
                                    <div class="guest-box" id="guestSelector">
                                        <span> <i class="fas fa-user me-2"></i><span id="guestDisplay">1 Adults, 0 Children</span> </span>
                                        <span><i class="fas fa-chevron-right"></i></span>
                                    </div>
                                    <div class="guest-dropdown" id="guestDropdown">
                                        <div class="guest-counter">
                                            <div>Adults</div>
                                            <div class="d-flex align-items-center">
                                                <button class="counter-btn" id="decreaseAdults">-</button>
                                                <span class="counter-value mx-2" id="adultCount">1</span>
                                                <button class="counter-btn" id="increaseAdults">+</button>
                                            </div>
                                        </div>
                                        <div class="guest-counter">
                                            <div>Children</div>
                                            <div class="d-flex align-items-center">
                                                <button class="counter-btn" id="decreaseChildren">-</button>
                                                <span class="counter-value mx-2" id="childCount">0</span>
                                                <button class="counter-btn" id="increaseChildren">+</button>
                                            </div>
                                        </div>
                                        <button class="btn btn-primary w-100 mt-2" id="applyGuests">Apply</button>
                                    </div>
                                </div>

                                <!-- Continue Button -->
                                <div class="navigation-buttons">
                                    <button class="btn btn-outline-secondary" disabled>Back</button>
                                    <button class="btn btn-primary" id="continueBtn">Continue to Hotels</button>
                                </div>
                            </div>
                        </div>

                        <!-- Step 2: Choose Hotel -->
                        <div class="container mb-5 step-content" id="step2">
                            <div class="row">
                                <!-- Filters Column -->
                                <div class="col-md-3">
                                    <div class="card p-3 mb-3 sticky-sidebar">
                                        <h5 class="fw-bold mb-3">Price Range</h5>
                                        <div class="d-flex justify-content-between mb-2">
                                            <span>₹0</span>
                                            <span>₹<span id="priceRangeValue">5000</span></span>
                                        </div>
                                        <input type="range" class="form-range price-range-slider" min="0" max="5000" id="priceRange">
                                        
                                        <h5 class="fw-bold mt-4 mb-3">Star Rating</h5>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input star-rating-checkbox" type="checkbox" id="rating5">
                                            <label class="form-check-label" for="rating5">★★★★★</label>
                                        </div>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input star-rating-checkbox" type="checkbox" id="rating4">
                                            <label class="form-check-label" for="rating4">★★★★</label>
                                        </div>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input star-rating-checkbox" type="checkbox" id="rating3">
                                            <label class="form-check-label" for="rating3">★★★</label>
                                        </div>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input star-rating-checkbox" type="checkbox" id="rating1">
                                            <label class="form-check-label" for="rating1">★</label>
                                        </div>
                                        
                                        <h5 class="fw-bold mt-4 mb-3">Amenities</h5>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input amenities-checkbox" type="checkbox" id="wifi">
                                            <label class="form-check-label" for="wifi">WiFi</label>
                                        </div>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input amenities-checkbox" type="checkbox" id="pool">
                                            <label class="form-check-label" for="pool">Pool</label>
                                        </div>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input amenities-checkbox" type="checkbox" id="parking">
                                            <label class="form-check-label" for="parking">Parking</label>
                                        </div>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input amenities-checkbox" type="checkbox" id="ac">
                                            <label class="form-check-label" for="ac">Air Conditioning</label>
                                        </div>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input amenities-checkbox" type="checkbox" id="restaurant">
                                            <label class="form-check-label" for="restaurant">Restaurant</label>
                                        </div>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input amenities-checkbox" type="checkbox" id="fitness">
                                            <label class="form-check-label" for="fitness">Fitness Center</label>
                                        </div>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input amenities-checkbox" type="checkbox" id="temple">
                                            <label class="form-check-label" for="temple">Temple Nearby</label>
                                        </div>
                                        <div class="form-check mb-2">
                                            <input class="form-check-input amenities-checkbox" type="checkbox" id="beach">
                                            <label class="form-check-label" for="beach">Beach Access</label>
                                        </div>
                                        
                                        <div class="d-grid gap-2 mt-4">
                                            <button class="btn btn-outline-secondary" id="resetFilters">Reset</button>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Hotels Column -->
                                <div class="col-md-9">
                                    <div class="card p-3 mb-3">
                                        <h4 class="fw-bold" id="destinationDisplay">N/A</h4>
                                        <p class="text-muted m-0" id="bookingDetailsDisplay">N/A</p>
                                    </div>
                                    
                                    <!-- Hotel Cards -->
                                    <div class="hotel-grid" id="hotelList">
                                        <!-- Hotel cards will be populated by JavaScript -->
                                    </div>

                                    <!-- Navigation Buttons -->
                                    <div class="navigation-buttons mt-4">
                                        <button class="btn btn-outline-secondary" id="backToDatesBtn">Back to Dates</button>
                                        <button class="btn btn-primary" id="continueToRoomsBtn" disabled>Continue to Rooms</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Step 3: Select Room -->
                        <div class="container mb-5 step-content" id="step3">
                            <div class="row">
                                <!-- Carousel Section -->
                                <div id="hotelCarousel" class="carousel slide mb-4" data-bs-ride="carousel">
                                    <div class="carousel-inner rounded" id="hotelImageSlider">
                                        <!-- Carousel items will be populated by JavaScript -->
                                    </div>
                                </div>

                                <div class="col-md-8">
                                    <div class="card p-4 mb-4">
                                        <h2 class="mb-3" id="hotelNameDisplay">Hotel Name</h2>
                                        <p class="text-muted"><i class="fas fa-star text-warning"></i> <strong>4.8</strong> (324 reviews) • <i class="fas fa-map-marker-alt"></i> <span id="hotelLocationDisplay">Location</span></p>
                                        
                                        <p id="hotelDescriptionDisplay">Hotel description will appear here.</p>
                                        
                                        <h4 class="mt-4 mb-3">Amenities</h4>
                                        <div class="row" id="hotelAmenitiesDisplay">
                                            <!-- Amenities will be populated by JavaScript -->
                                        </div>
                                    </div>

                                    <h3 class="mb-4">Select Your Room</h3>
                                    
                                    <!-- Room Cards -->
                                    <div id="roomSelectionContainer">
                                        <!-- Room cards will be populated by JavaScript -->
                                    </div>

                                    <h3 class="mt-5 mb-4">Guest Reviews</h3>
                                    
                                    <div id="hotelReviewsContainer">
                                        <!-- Reviews will be populated by JavaScript -->
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="card p-4 sticky-sidebar">
                                        <h4 class="mb-3">Your Booking Summary</h4>
                                        
                                        <div id="selectedRoomDisplay" class="selected-room" style="display: none;">
                                            <h5 id="selectedRoomType"></h5>
                                            <p id="selectedRoomPrice" class="mb-0"></p>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <h6>Dates</h6>
                                            <p id="bookingDatesSummary" class="text-muted"></p>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <h6>Guests</h6>
                                            <p id="bookingGuestsSummary" class="text-muted"></p>
                                        </div>
                                        
                                        <div class="mb-4">
                                            <h6>Price Breakdown</h6>
                                            <div class="d-flex justify-content-between">
                                                <span>Room (x nights)</span>
                                                <span id="roomSubtotal">₹0</span>
                                            </div>
                                            <div class="d-flex justify-content-between">
                                                <span>Taxes & Fees</span>
                                                <span>₹99</span>
                                            </div>
                                            <hr>
                                            <div class="d-flex justify-content-between fw-bold">
                                                <span>Total</span>
                                                <span id="bookingTotal">₹0</span>
                                            </div>
                                        </div>
                                        
                                        <button class="btn btn-primary w-100" id="continueToConfirmationBtn" disabled>Continue to Confirmation</button>
                                        <button class="btn btn-outline-secondary w-100 mt-2" id="backToHotelsBtn">Back to Hotels</button>
                                    </div>
                                    <div class="card p-4 mt-4 sticky-sidebar">
                                        <h4 class="mb-0">Location <span  id="hotelMap"></span></h4>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Step 4: Confirm Booking -->
                        <div class="container mb-5 step-content" id="step4">
                            <div class="row justify-content-center">
                                <div class="col-md-8">
                                    <div class="card p-5 text-center">
                                        <div class="mb-4">
                                            <i class="fas fa-check-circle text-success" style="font-size: 5rem;"></i>
                                        </div>
                                        <h2 class="mb-3">Booking Confirmed!</h2>
                                        <p class="text-muted mb-4">Thank you for choosing TNBooking.in. We've sent a confirmation email to your registered email address.</p>
                                        
                                        <div class="card mb-4">
                                            <div class="card-body text-start">
                                                <h4 class="mb-3" id="confirmationHotelName">N/A</h4>
                                                <p class="text-muted" id="confirmationDates">N/A</p>
                                                <p class="text-muted" id="confirmationRoomType">N/A</p>
                                                <p class="text-muted" id="confirmationGuests">N/A</p>
                                                <hr>
                                                <div class="d-flex justify-content-between fw-bold">
                                                    <span>Total</span>
                                                    <span id="confirmationTotal">₹0</span>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <button class="btn btn-primary w-100" id="backToHomeBtn">Back to Home</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include "temp/footer.php" ?>

        <script src="assets/js/booking.js"></script>
        
    </body>
</html>