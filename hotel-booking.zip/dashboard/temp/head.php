<link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon">

<!-- Bootstrap 5 -->
<link href="assets/css/libs/5.3.3/bootstrap.min.css" rel="stylesheet" />
<link href="assets/css/libs/1.13.1/bootstrap-icons.min.css" rel="stylesheet">
<!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"> -->

<!-- Icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.0/css/all.min.css" />
<link rel="stylesheet" href="assets/css/libs/7.0.0/all.min.css" />

<!-- Google Fonts: Inter -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />

<link rel="stylesheet" href="assets/css/style.css">

<link rel="stylesheet" href="assets/css/libs/sweetalert2.min.css" />
<link href="assets/css/libs/5.9.3/dropzone.min.css" rel="stylesheet">