<?php
${basename(__FILE__, '.php')} = function () {
    if ($this->get_request_method() != "POST") {
        $this->response($this->json([
            'message' => 'Method Not Allowed'
        ]), 405);
        return;
    }

    if ($this->paramsExists(['hotel_id', 'check_in', 'check_out'])) {
        $hotel_id = $this->_request['hotel_id'];
        $check_in = $this->_request['check_in'];
        $check_out = $this->_request['check_out'];

        // Get available rooms for the hotel
        $available_rooms = Admin::getAvailableRooms($hotel_id, $check_in, $check_out);
        
        $this->response($this->json([
            'success' => true,
            'available_rooms' => count($available_rooms),
            'rooms' => $available_rooms
        ]), 200);

    } else {
        $this->response($this->json([
            'success' => false,
            'message' => "Bad Request - Missing required parameters"
        ]), 400);
    }
};