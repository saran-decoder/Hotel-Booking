<link rel="shortcut icon" href="public/assets/images/favicon.png" type="image/x-icon" />

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="public/assets/css/libs/5.3.3/bootstrap.min.css" />
<!-- Bootstrap Icons -->
<!-- <link rel="stylesheet" href="assets/css/libs/1.13.1/bootstrap-icons.min.css" /> -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">

<link rel="stylesheet" href="public/assets/css/style.css" />

<style>
    .btn-close {
        z-index: 10;
    }
    .modal-header {
        border-bottom: none;
    }
    .modal-footer {
        border-top: none;
    }
    .form-control:focus {
        box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
    }
</style>